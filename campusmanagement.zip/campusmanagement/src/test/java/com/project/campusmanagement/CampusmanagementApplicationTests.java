package com.project.campusmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
